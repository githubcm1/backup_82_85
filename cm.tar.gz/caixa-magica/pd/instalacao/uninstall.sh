sudo rm -fR "/home/pi/caixa-magica"
sudo rm /lib/libbio.so
sudo rm /lib/ftrapi.so
sudo rm /lib/libScanAPI.so
sudo rm "/home/pi/Desktop/run_caixa_magica.sh"
sudo rm "/home/pi/Desktop/run_gravador.sh"
