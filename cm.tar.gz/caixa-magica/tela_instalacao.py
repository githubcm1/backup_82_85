path = "/home/pi/caixa-magica/tela/"
import sys
sys.path.insert(1, path)

from funcoes_telas import TelaAguardeInstala

TelaAguardeInstala()

