echo "Iniciando caixa magica"
sudo python3 start.py
