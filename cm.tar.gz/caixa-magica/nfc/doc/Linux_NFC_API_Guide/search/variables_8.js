var searchData=
[
  ['ndef',['ndef',['../structnfc__btoob__pairing__t.html#a56c1d82c331bb22243b9eb2c22a0d69c',1,'nfc_btoob_pairing_t::ndef()'],['../structnfc__wifi__pairing__t.html#a6a8183ef1899f996f7d0868c6f6c5ae0',1,'nfc_wifi_pairing_t::ndef()'],['../structnfc__wifi__request__t.html#a4cf518a0af9b5524d9c6d4f5a0fe003a',1,'nfc_wifi_request_t::ndef()']]],
  ['ndef_5flength',['ndef_length',['../structnfc__btoob__pairing__t.html#a912b1dafa4dfc1d3a1db792264e3962e',1,'nfc_btoob_pairing_t::ndef_length()'],['../structnfc__wifi__pairing__t.html#af36b109934a2a2d93bbdd2cf431dbe31',1,'nfc_wifi_pairing_t::ndef_length()'],['../structnfc__wifi__request__t.html#aac33d97bee002ca29c65afafff6081ad',1,'nfc_wifi_request_t::ndef_length()']]]
];
