var searchData=
[
  ['default_5fnfa_5ftech_5fmask',['DEFAULT_NFA_TECH_MASK',['../linux__nfc__api_8h.html#a30bfe94762be1486a4dd80c17fa940a2',1,'linux_nfc_api.h']]],
  ['device_5fname',['device_name',['../structnfc__btoob__pairing__t.html#a3d92f5d1d624e303432eb6ceaf099f33',1,'nfc_btoob_pairing_t']]],
  ['device_5fname_5flength',['device_name_length',['../structnfc__btoob__pairing__t.html#a50389448189c288965ca80bafc272e5a',1,'nfc_btoob_pairing_t']]]
];
