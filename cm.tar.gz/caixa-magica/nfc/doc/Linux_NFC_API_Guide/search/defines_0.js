var searchData=
[
  ['default_5fnfa_5ftech_5fmask',['DEFAULT_NFA_TECH_MASK',['../linux__nfc__api_8h.html#a30bfe94762be1486a4dd80c17fa940a2',1,'linux_nfc_api.h']]]
];
