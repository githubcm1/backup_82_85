var searchData=
[
  ['ondatareceived',['onDataReceived',['../structnfc_host_card_emulation_callback__t.html#a8cb71a8207203bb827375b735a824545',1,'nfcHostCardEmulationCallback_t']]],
  ['ondevicearrival',['onDeviceArrival',['../structnfc_snep_server_callback__t.html#aa1fa5aa1156a33599b7b238c2a5242d8',1,'nfcSnepServerCallback_t::onDeviceArrival()'],['../structnfc_snep_client_callback__t.html#a4633f5b3a61001248290c63f1beee3a1',1,'nfcSnepClientCallback_t::onDeviceArrival()']]],
  ['ondevicedeparture',['onDeviceDeparture',['../structnfc_snep_server_callback__t.html#af9f6e0a0d6d4ef5e2a1d626c6a60745d',1,'nfcSnepServerCallback_t::onDeviceDeparture()'],['../structnfc_snep_client_callback__t.html#a7cec60e7a871e3fa5b8e4698fa7a441f',1,'nfcSnepClientCallback_t::onDeviceDeparture()']]],
  ['onhandoverrequestreceived',['onHandoverRequestReceived',['../structnfc_handover_callback__t.html#abf4713cafbfca6e8b3ab9396a2eef602',1,'nfcHandoverCallback_t']]],
  ['onhandoverselectreceived',['onHandoverSelectReceived',['../structnfc_handover_callback__t.html#ad16d97ef8794f16ab3f54fdc95f49c11',1,'nfcHandoverCallback_t']]],
  ['onhostcardemulationactivated',['onHostCardEmulationActivated',['../structnfc_host_card_emulation_callback__t.html#a87c79c203d878b56b1d4a686fecc95ac',1,'nfcHostCardEmulationCallback_t']]],
  ['onhostcardemulationdeactivated',['onHostCardEmulationDeactivated',['../structnfc_host_card_emulation_callback__t.html#a2d2da4dcbb1071939d30e99cbae89178',1,'nfcHostCardEmulationCallback_t']]],
  ['onmessagereceived',['onMessageReceived',['../structnfc_snep_server_callback__t.html#a83f235498ed61e567c23d527b1caf629',1,'nfcSnepServerCallback_t']]],
  ['ontagarrival',['onTagArrival',['../structnfc_tag_callback__t.html#a2169464514c76c027f68528aaa22c707',1,'nfcTagCallback_t']]],
  ['ontagdeparture',['onTagDeparture',['../structnfc_tag_callback__t.html#ad25aa5616b50732c6c69aa6ed8d8775c',1,'nfcTagCallback_t']]]
];
