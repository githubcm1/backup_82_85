var searchData=
[
  ['flag_5fhce_5fenable_5fhce',['FLAG_HCE_ENABLE_HCE',['../linux__nfc__api_8h.html#a8ca369281b4b9bedbcd9d738085e2922',1,'linux_nfc_api.h']]],
  ['flag_5fhce_5fskip_5fndef_5fcheck',['FLAG_HCE_SKIP_NDEF_CHECK',['../linux__nfc__api_8h.html#adaa7628f126663e1651667b8cb9b0574',1,'linux_nfc_api.h']]]
];
