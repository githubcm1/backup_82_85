var searchData=
[
  ['technology',['technology',['../structnfc__tag__info__t.html#ae86261692eb29257980f646402880367',1,'nfc_tag_info_t']]],
  ['type',['type',['../structnfc__btoob__pairing__t.html#adba44a81c741d47f12c4bd3ea049434b',1,'nfc_btoob_pairing_t']]]
];
