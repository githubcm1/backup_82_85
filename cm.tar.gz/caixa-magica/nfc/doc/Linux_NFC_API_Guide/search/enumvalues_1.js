var searchData=
[
  ['ndef_5ffriendly_5ftype_5fhr',['NDEF_FRIENDLY_TYPE_HR',['../linux__nfc__api_8h.html#a76218cd68b3ea6ea520a9800cd9b55d2acdeea0ff156c848ed583906698bc7da3',1,'linux_nfc_api.h']]],
  ['ndef_5ffriendly_5ftype_5fhs',['NDEF_FRIENDLY_TYPE_HS',['../linux__nfc__api_8h.html#a76218cd68b3ea6ea520a9800cd9b55d2ab8323cffdbaf9a547ea49dbb6019ea32',1,'linux_nfc_api.h']]],
  ['ndef_5ffriendly_5ftype_5fother',['NDEF_FRIENDLY_TYPE_OTHER',['../linux__nfc__api_8h.html#a76218cd68b3ea6ea520a9800cd9b55d2a869d1640610b7a8d4ac479668f873e6d',1,'linux_nfc_api.h']]],
  ['ndef_5ffriendly_5ftype_5ftext',['NDEF_FRIENDLY_TYPE_TEXT',['../linux__nfc__api_8h.html#a76218cd68b3ea6ea520a9800cd9b55d2a0a4c2483a36535c0f9ba336fee9383d7',1,'linux_nfc_api.h']]],
  ['ndef_5ffriendly_5ftype_5furl',['NDEF_FRIENDLY_TYPE_URL',['../linux__nfc__api_8h.html#a76218cd68b3ea6ea520a9800cd9b55d2aa7a414cabdf317fe6fb1dd435b7dd1aa',1,'linux_nfc_api.h']]],
  ['nfc_5ffactory_5fbit_5frate_5f106',['NFC_FACTORY_BIT_RATE_106',['../linux__nfc__factory__api_8h.html#a0bbddf1386f0100bcc4bfeba426a3344af3c5888d933ebc3bc3319979947e6837',1,'linux_nfc_factory_api.h']]],
  ['nfc_5ffactory_5fbit_5frate_5f212',['NFC_FACTORY_BIT_RATE_212',['../linux__nfc__factory__api_8h.html#a0bbddf1386f0100bcc4bfeba426a3344aa9cd7cf6c2836091ab523e4489367dee',1,'linux_nfc_factory_api.h']]],
  ['nfc_5ffactory_5fbit_5frate_5f424',['NFC_FACTORY_BIT_RATE_424',['../linux__nfc__factory__api_8h.html#a0bbddf1386f0100bcc4bfeba426a3344a29b0099a9dc7bb98f4a8c2df903f92ad',1,'linux_nfc_factory_api.h']]],
  ['nfc_5ffactory_5fbit_5frate_5f848',['NFC_FACTORY_BIT_RATE_848',['../linux__nfc__factory__api_8h.html#a0bbddf1386f0100bcc4bfeba426a3344a9720272d466881b0681e50ddfd6dfd6d',1,'linux_nfc_factory_api.h']]],
  ['nfc_5ffactory_5frf_5ftechnology_5fa',['NFC_FACTORY_RF_TECHNOLOGY_A',['../linux__nfc__factory__api_8h.html#af507e085fb991b2ef57d57304eaa9093af6c299087f9c328fe280ccb385dc636e',1,'linux_nfc_factory_api.h']]],
  ['nfc_5ffactory_5frf_5ftechnology_5fb',['NFC_FACTORY_RF_TECHNOLOGY_B',['../linux__nfc__factory__api_8h.html#af507e085fb991b2ef57d57304eaa9093a800b2f7957ac2467e58e36ba8e035bb8',1,'linux_nfc_factory_api.h']]],
  ['nfc_5ffactory_5frf_5ftechnology_5ff',['NFC_FACTORY_RF_TECHNOLOGY_F',['../linux__nfc__factory__api_8h.html#af507e085fb991b2ef57d57304eaa9093a4516618f4a3ffcee9c19060a8aaab9dc',1,'linux_nfc_factory_api.h']]]
];
