var searchData=
[
  ['key',['key',['../structnfc__wifi__pairing__t.html#a74640c5faed8fa7cc73dd72f3a59d4d7',1,'nfc_wifi_pairing_t']]],
  ['key_5flength',['key_length',['../structnfc__wifi__pairing__t.html#aa045f1d547271bf0e09da158f306488f',1,'nfc_wifi_pairing_t']]]
];
