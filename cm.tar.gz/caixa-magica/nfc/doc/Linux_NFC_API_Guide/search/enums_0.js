var searchData=
[
  ['nfc_5ffriendly_5ftype_5ft',['nfc_friendly_type_t',['../linux__nfc__api_8h.html#a76218cd68b3ea6ea520a9800cd9b55d2',1,'linux_nfc_api.h']]],
  ['nfc_5fhandover_5fbt_5ftype_5ft',['nfc_handover_bt_type_t',['../linux__nfc__api_8h.html#a8b59b6a55393811dd22637a66cfcfbf6',1,'linux_nfc_api.h']]],
  ['nfc_5fhandover_5fcps_5ft',['nfc_handover_cps_t',['../linux__nfc__api_8h.html#a7c6b0ba3e307e06fe009338c6899c0ab',1,'linux_nfc_api.h']]],
  ['nfcfactory_5fprbsbitrate_5ft',['nfcFactory_PRBSBitrate_t',['../linux__nfc__factory__api_8h.html#a0bbddf1386f0100bcc4bfeba426a3344',1,'linux_nfc_factory_api.h']]],
  ['nfcfactory_5fprbstech_5ft',['nfcFactory_PRBSTech_t',['../linux__nfc__factory__api_8h.html#af507e085fb991b2ef57d57304eaa9093',1,'linux_nfc_factory_api.h']]]
];
