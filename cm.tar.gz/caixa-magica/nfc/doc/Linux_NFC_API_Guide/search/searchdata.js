var indexSectionsWithContent =
{
  0: "abcdfhiklmnopstuw",
  1: "n",
  2: "lm",
  3: "n",
  4: "abcdhikmnopstuw",
  5: "nt",
  6: "n",
  7: "hn",
  8: "dfnt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros"
};

