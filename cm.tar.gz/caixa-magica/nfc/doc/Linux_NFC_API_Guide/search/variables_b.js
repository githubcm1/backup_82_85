var searchData=
[
  ['ssid',['ssid',['../structnfc__wifi__pairing__t.html#a2550dd60e0a3c28016bcf00211a40d76',1,'nfc_wifi_pairing_t']]],
  ['ssid_5flength',['ssid_length',['../structnfc__wifi__pairing__t.html#a0b5d0473b67e95de4974425c55d88fdb',1,'nfc_wifi_pairing_t']]]
];
