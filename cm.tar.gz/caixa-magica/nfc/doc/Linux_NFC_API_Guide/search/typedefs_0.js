var searchData=
[
  ['nfc_5fbtoob_5frequest_5ft',['nfc_btoob_request_t',['../linux__nfc__api_8h.html#aad6b282cdfe3a0ea400cfc1419666a0d',1,'linux_nfc_api.h']]]
];
