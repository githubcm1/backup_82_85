var searchData=
[
  ['ndef_5finfo_5ft',['ndef_info_t',['../structndef__info__t.html',1,'']]],
  ['nfc_5fbtoob_5fpairing_5ft',['nfc_btoob_pairing_t',['../structnfc__btoob__pairing__t.html',1,'']]],
  ['nfc_5fhandover_5frequest_5ft',['nfc_handover_request_t',['../structnfc__handover__request__t.html',1,'']]],
  ['nfc_5fhandover_5fselect_5ft',['nfc_handover_select_t',['../structnfc__handover__select__t.html',1,'']]],
  ['nfc_5ftag_5finfo_5ft',['nfc_tag_info_t',['../structnfc__tag__info__t.html',1,'']]],
  ['nfc_5fwifi_5fpairing_5ft',['nfc_wifi_pairing_t',['../structnfc__wifi__pairing__t.html',1,'']]],
  ['nfc_5fwifi_5frequest_5ft',['nfc_wifi_request_t',['../structnfc__wifi__request__t.html',1,'']]],
  ['nfcfactory_5fantenna_5fst_5fresp_5ft',['nfcFactory_Antenna_St_Resp_t',['../structnfc_factory___antenna___st___resp__t.html',1,'']]],
  ['nfchandovercallback_5ft',['nfcHandoverCallback_t',['../structnfc_handover_callback__t.html',1,'']]],
  ['nfchostcardemulationcallback_5ft',['nfcHostCardEmulationCallback_t',['../structnfc_host_card_emulation_callback__t.html',1,'']]],
  ['nfcsnepclientcallback_5ft',['nfcSnepClientCallback_t',['../structnfc_snep_client_callback__t.html',1,'']]],
  ['nfcsnepservercallback_5ft',['nfcSnepServerCallback_t',['../structnfc_snep_server_callback__t.html',1,'']]],
  ['nfctagcallback_5ft',['nfcTagCallback_t',['../structnfc_tag_callback__t.html',1,'']]]
];
