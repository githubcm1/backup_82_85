var searchData=
[
  ['is_5fndef',['is_ndef',['../structndef__info__t.html#a210aa7d6be8d2488af3c32a6f1882953',1,'ndef_info_t']]],
  ['is_5fwritable',['is_writable',['../structndef__info__t.html#a181e9b302e56bfd9fb2d3d7373fee5a9',1,'ndef_info_t']]]
];
