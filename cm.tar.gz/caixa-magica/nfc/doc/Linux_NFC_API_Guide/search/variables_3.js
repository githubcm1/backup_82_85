var searchData=
[
  ['device_5fname',['device_name',['../structnfc__btoob__pairing__t.html#a3d92f5d1d624e303432eb6ceaf099f33',1,'nfc_btoob_pairing_t']]],
  ['device_5fname_5flength',['device_name_length',['../structnfc__btoob__pairing__t.html#a50389448189c288965ca80bafc272e5a',1,'nfc_btoob_pairing_t']]]
];
