echo '[]' > /home/pi/caixa-magica-operacao/abertura_offline_excecoes.json
