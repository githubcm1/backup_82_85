sudo pkill -9 -f python3
sleep 2
sudo pkill -9 -f python3
sleep 2
sudo pkill -9 -f python3
sleep 2
sudo pkill -9 -f pyconcrete
