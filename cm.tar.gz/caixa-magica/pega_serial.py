from core import funcoes_serial

serial = funcoes_serial.getSerial()

print("Serial: " + str(serial))
