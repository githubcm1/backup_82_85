#sudo pkill -9 -f python3
#sudo pkill -9 -f pyconcrete

echo "Iniciando teste_hw"
sudo python3 /home/pi/caixa-magica/teste_hw/view.py
