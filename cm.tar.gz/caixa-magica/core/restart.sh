sudo killall -9 python3
sudo killalll -9 python
sudo pkill -9 python3
cd /home/pi/caixa-magica/core
chmod +x telaInicializacao.py
sudo ./telaInicializacao.py