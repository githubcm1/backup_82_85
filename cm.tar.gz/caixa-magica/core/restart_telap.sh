sudo killall -9 python3
cd /home/pi/caixa-magica/core
sudo python3 telaInicializacao.py