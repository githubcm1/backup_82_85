import multiprocessing

print(multiprocessing.cpu_count())
