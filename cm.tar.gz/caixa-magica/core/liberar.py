import operacoes
operacoes.liberar()
