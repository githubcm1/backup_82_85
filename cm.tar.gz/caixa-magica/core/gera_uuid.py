import uuid

# Funcao para geracao de UUID
def gera_uuid():
    return str(uuid.uuid4())

